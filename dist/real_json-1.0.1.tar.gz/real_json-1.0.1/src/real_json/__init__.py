from real_json.GetWrappedJson import GetWrappedJson

__version__ = "1.0.1"


def ify(obj):
    return GetWrappedJson(obj)
