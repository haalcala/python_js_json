# python_js_json
Wrapper class so that you can access `dict` and `list` as easily as in Javascript
