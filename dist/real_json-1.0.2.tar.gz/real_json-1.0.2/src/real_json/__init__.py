from real_json.GetWrappedJson import GetWrappedJson

__version__ = "1.0.2"


def ify(obj):
    return GetWrappedJson(obj)
